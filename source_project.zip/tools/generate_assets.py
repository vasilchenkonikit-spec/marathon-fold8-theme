from pathlib import Path
from PIL import Image,ImageDraw,ImageFont
import os,math
ROOT=Path(__file__).resolve().parents[1]; RES=ROOT/'app/src/main/res/drawable-nodpi';RES.mkdir(parents=True,exist_ok=True)
LIME=(223,255,0); INK=(12,17,17); CYAN=(0,216,229); MAGENTA=(240,42,152)
def font(sz,b=False):
 p='/usr/share/fonts/truetype/dejavu/DejaVuSansMono-Bold.ttf' if b else '/usr/share/fonts/truetype/dejavu/DejaVuSansMono.ttf'
 return ImageFont.truetype(p,sz) if os.path.exists(p) else ImageFont.load_default()
def wallpaper(size,lock=False):
 W,H=size;im=Image.new('RGB',size,LIME);d=ImageDraw.Draw(im);step=max(34,W//32)
 for x in range(0,W,step):
  for y in range(0,H,step):d.ellipse((x,y,x+2,y+2),fill=(206,235,0))
 cx=int(W*(.5 if lock else .68));cy=int(H*(.54 if lock else .38));r=int(min(W,H)*(.30 if lock else .22))
 for rr,w in [(r,3),(int(r*.68),2)]:d.ellipse((cx-rr,cy-rr,cx+rr,cy+rr),outline=(90,108,0),width=w)
 d.line((cx-int(r*1.25),cy,cx+int(r*1.25),cy),fill=(70,85,0),width=2);d.line((cx,cy-int(r*1.25),cx,cy+int(r*1.25)),fill=(70,85,0),width=2)
 for i in range(8):y=int(H*(.08+i*.11));d.rectangle((int(W*.025),y,int(W*.055),y+4),fill=INK)
 d.text((int(W*.07),int(H*.06)),'MARATHON // TAU CETI IV',fill=INK,font=font(max(20,W//44),True))
 if lock:d.text((int(W*.5),int(H*.76)),'FOR THE RUNNERS',fill=INK,font=font(max(16,W//65),True),anchor='mm')
 else:d.text((int(W*.86),int(H*.14)),'SYS\nONLINE',fill=INK,font=font(max(15,W//75),True))
 return im
wallpaper((1848,2448),False).save(RES/'wallpaper_home.jpg',quality=91,optimize=True);wallpaper((1848,2448),True).save(RES/'wallpaper_lock.jpg',quality=91,optimize=True)
def base():
 im=Image.new('RGBA',(512,512),(0,0,0,0));d=ImageDraw.Draw(im);d.rounded_rectangle((28,28,484,484),radius=92,fill=LIME);d.rounded_rectangle((84,84,428,416),radius=70,fill=INK);d.rectangle((95,442,240,450),fill=INK);d.rectangle((252,442,315,450),fill=CYAN);d.rectangle((327,442,390,450),fill=MAGENTA);return im,d
def save(kind):
 im,d=base();c=LIME
 if kind=='phone':d.arc((135,115,382,385),130,303,fill=c,width=42);d.rounded_rectangle((112,116,175,220),24,fill=c);d.rounded_rectangle((337,282,400,386),24,fill=c)
 elif kind=='messages':d.rounded_rectangle((115,145,397,340),50,fill=c);d.polygon([(185,340),(155,395),(250,340)],fill=c);[d.ellipse((x-12,235-12,x+12,235+12),fill=INK) for x in (190,256,322)]
 elif kind=='camera':d.rounded_rectangle((110,160,402,350),42,fill=c);d.rectangle((175,125,250,170),fill=c);d.ellipse((185,185,327,327),fill=INK);d.ellipse((220,220,292,292),fill=c)
 elif kind=='gallery':
  for x,y in [(180,180),(332,180),(180,332),(332,332)]:d.ellipse((x-42,y-42,x+42,y+42),fill=c)
 elif kind=='browser':d.ellipse((120,120,392,392),outline=c,width=32);d.arc((170,105,342,407),80,280,fill=c,width=22);d.line((145,256,367,256),fill=c,width=20)
 elif kind=='youtube':d.rounded_rectangle((110,155,402,357),55,fill=c);d.polygon([(225,200),(225,312),(327,256)],fill=INK)
 elif kind=='gmail':d.rounded_rectangle((112,150,400,362),40,fill=c);d.line((125,170,256,275,387,170),fill=INK,width=22)
 elif kind=='maps':d.ellipse((165,105,347,287),fill=c);d.polygon([(256,405),(175,250),(337,250)],fill=c);d.ellipse((225,165,287,227),fill=INK)
 elif kind=='calendar':d.rounded_rectangle((125,120,387,392),45,fill=c);d.rectangle((125,172,387,215),fill=INK);d.text((190,232),'23',fill=INK,font=font(80,True))
 elif kind=='clock':d.ellipse((120,120,392,392),outline=c,width=30);d.line((256,256,256,175),fill=c,width=25);d.line((256,256,330,298),fill=c,width=25)
 elif kind=='settings':
  d.ellipse((175,175,337,337),outline=c,width=32)
  for i in range(8):
   a=math.radians(i*45);x=256+math.cos(a)*135;y=256+math.sin(a)*135;d.rounded_rectangle((x-20,y-42,x+20,y+42),15,fill=c)
 elif kind=='files':d.rounded_rectangle((110,155,402,365),40,fill=c);d.polygon([(110,180),(110,125),(225,125),(260,160),(402,160),(402,210),(110,210)],fill=c)
 elif kind=='calculator':d.rounded_rectangle((135,100,377,405),42,fill=c);[(d.ellipse((x-16,y-16,x+16,y+16),fill=INK)) for y in (200,265,330) for x in (190,256,322)]
 elif kind=='telegram':d.polygon([(105,240),(407,125),(333,390),(250,303),(180,345)],fill=c);d.line((180,345,250,303,333,390),fill=INK,width=10)
 elif kind=='whatsapp':d.ellipse((110,110,402,402),fill=c);d.polygon([(140,350),(110,420),(195,390)],fill=c);d.arc((175,175,337,337),135,325,fill=INK,width=28)
 elif kind=='spotify':
  d.ellipse((110,110,402,402),fill=c)
  for o in (0,38,76):d.arc((165,175+o,350,285+o),205,330,fill=INK,width=18)
 elif kind=='play_store':d.polygon([(135,105),(390,256),(135,407)],fill=c);d.line((180,185,310,256,180,327),fill=INK,width=18)
 elif kind=='samsung_health':d.polygon([(256,390),(130,270),(130,190),(175,145),(225,145),(256,185),(287,145),(337,145),(382,190),(382,270)],fill=c);d.line((165,255,220,255,245,210,275,300,302,255,347,255),fill=INK,width=16)
 elif kind=='wallet':d.rounded_rectangle((115,150,397,365),42,fill=c);d.rounded_rectangle((265,205,415,310),30,fill=INK);d.ellipse((302,245,330,273),fill=c)
 elif kind=='bank':d.polygon([(110,190),(256,105),(402,190)],fill=c);[d.rectangle((x-14,195,x+14,340),fill=c) for x in (155,225,295,365)];d.rectangle((110,350,402,390),fill=c)
 elif kind=='yandex':d.text((175,130),'Y',fill=c,font=font(210,True))
 elif kind=='obsidian':d.polygon([(256,90),(370,180),(335,385),(256,425),(177,385),(142,180)],fill=c);d.line((210,190,302,330,245,365),fill=INK,width=18)
 elif kind=='vk':d.text((145,165),'VK',fill=c,font=font(100,True))
 else:d.ellipse((150,150,362,362),outline=c,width=28)
 im.save(RES/(kind+'.png'))
for k in ['phone','messages','camera','gallery','browser','youtube','gmail','maps','calendar','clock','settings','files','calculator','telegram','whatsapp','spotify','play_store','samsung_health','wallet','bank','yandex','obsidian','vk']:save(k)
# app icon
im,d=base();d.ellipse((145,145,367,367),outline=LIME,width=28);d.line((105,256,407,256),fill=LIME,width=16);d.line((256,105,256,407),fill=LIME,width=16);im.save(RES/'icon_marathon.png')
print('Generated Marathon v2 resources')
