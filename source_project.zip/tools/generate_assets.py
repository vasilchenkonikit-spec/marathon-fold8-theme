from pathlib import Path
from PIL import Image, ImageDraw, ImageFont
import os, re, xml.etree.ElementTree as ET

ROOT=Path(__file__).resolve().parents[1]
TOOLS=ROOT/'tools'
RES=ROOT/'app/src/main/res/drawable-nodpi'
RES.mkdir(parents=True,exist_ok=True)
LIME=(215,255,0); INK=(16,21,21); CYAN=(0,216,229); MAGENTA=(240,42,152)

def font(sz,bold=False):
    ps=['/usr/share/fonts/truetype/dejavu/DejaVuSansMono-Bold.ttf' if bold else '/usr/share/fonts/truetype/dejavu/DejaVuSansMono.ttf']
    for x in ps:
        if os.path.exists(x): return ImageFont.truetype(x,sz)
    return ImageFont.load_default()

def cover(im,size):
    W,H=size; s=max(W/im.width,H/im.height); r=im.resize((int(im.width*s),int(im.height*s)),Image.Resampling.LANCZOS); x=(r.width-W)//2; y=(r.height-H)//2; return r.crop((x,y,x+W,y+H))

def wallpaper(size,lock=False):
    src=Image.open(TOOLS/'source_art.jpg').convert('RGB'); im=cover(src,size).convert('RGBA'); im=Image.alpha_composite(im,Image.new('RGBA',size,LIME+(58 if lock else 72,))); d=ImageDraw.Draw(im); W,H=size; lw=max(2,W//650); m=int(W*.055); l=int(W*.055)
    for x,y,sx,sy in [(m,m,1,1),(W-m,m,-1,1),(m,H-m,1,-1),(W-m,H-m,-1,-1)]: d.line((x,y,x+sx*l,y),fill=INK,width=lw); d.line((x,y,x,y+sy*l),fill=INK,width=lw)
    d.text((int(W*.07),int(H*.06)),'TAU CETI IV' if lock else 'RUNNER // NV-01',fill=INK,font=font(max(18,int(W*.023)),True)); d.text((int(W*.07),int(H*.095)),'LOCK INTERFACE // ACTIVE' if lock else 'SYSTEM ONLINE',fill=CYAN,font=font(max(13,int(W*.015)),True))
    if not lock: d.rounded_rectangle((int(W*.055),int(H*.79),int(W*.945),int(H*.955)),radius=max(22,int(W*.025)),fill=(16,21,21,38),outline=(16,21,21,85),width=lw)
    else: d.text((int(W*.07),int(H*.82)),'BIOSYNC 93%',fill=INK,font=font(max(16,int(W*.019)),True)); d.rectangle((int(W*.07),int(H*.86),int(W*.56),int(H*.872)),fill=INK); d.rectangle((int(W*.07),int(H*.86),int(W*.44),int(H*.872)),fill=(234,255,22))
    return im.convert('RGB')

for fn,size,lock in [('wallpaper_cover_home.jpg',(1248,1972),False),('wallpaper_cover_lock.jpg',(1248,1972),True),('wallpaper_inner_home.jpg',(1848,2448),False),('wallpaper_inner_lock.jpg',(1848,2448),True)]: wallpaper(size,lock).save(RES/fn,quality=90,optimize=True)

# Generate every icon listed in drawable.xml as a cohesive Marathon monogram icon.
xml=ROOT/'app/src/main/assets/drawable.xml'
root=ET.parse(xml).getroot(); names=[e.attrib['drawable'] for e in root.findall('item')]
for name in names:
    im=Image.new('RGBA',(512,512),(0,0,0,0)); d=ImageDraw.Draw(im); d.rounded_rectangle((28,28,484,484),radius=92,fill=LIME); d.rounded_rectangle((94,96,418,394),radius=64,fill=INK)
    parts=[x for x in name.split('_') if x]; label=(''.join(x[0] for x in parts[:2]) if len(parts)>1 else name[:2]).upper(); fs=118 if len(label)<=2 else 88; bb=d.textbbox((0,0),label,font=font(fs,True)); d.text(((512-(bb[2]-bb[0]))//2,(512-(bb[3]-bb[1]))//2-14),label,fill=LIME,font=font(fs,True)); d.rectangle((72,438,238,448),fill=INK); d.rectangle((250,438,312,448),fill=CYAN); d.rectangle((324,438,382,448),fill=MAGENTA); im.save(RES/(name+'.png'))

# App icon
icon=Image.new('RGBA',(512,512),(0,0,0,0)); d=ImageDraw.Draw(icon); d.rounded_rectangle((28,28,484,484),radius=92,fill=LIME); d.ellipse((140,140,372,372),outline=INK,width=28); d.line((102,256,410,256),fill=INK,width=18); d.line((256,102,256,410),fill=INK,width=18); icon.save(RES/'icon_marathon.png')
print('Generated',len(names),'icons + wallpapers')
