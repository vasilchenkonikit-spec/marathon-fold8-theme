# Marathon Theme Installer for Galaxy Z Fold8

Target: Galaxy Z Fold8 / One UI 9
Primary color: #D7FF00

This project builds a real Android APK with:
- one-tap Home wallpaper
- one-tap Lock wallpaper
- third-party icon-pack resources for Theme Park / launchers
- quick-launch buttons for Good Lock modules
- embedded Marathon palette

## Build
GitHub Actions: Actions -> Build Marathon APK -> Run workflow.
Artifact name: `Marathon-Theme-Installer`

## Limits
Android does not expose public APIs that allow a normal sideloaded app to silently rewrite
Theme Park / QuickStar / LockStar / Keys Cafe settings. Those require a user action or
Samsung's own Galaxy To Share workflow.

Icon resources: 85
Explicit component mappings currently included: 76
