package com.nv.marathontheme;

import android.app.Activity;
import android.app.WallpaperManager;
import android.app.role.RoleManager;
import android.content.Context;
import android.content.Intent;
import android.content.pm.ActivityInfo;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.graphics.*;
import android.graphics.drawable.Drawable;
import android.os.*;
import android.provider.Settings;
import android.view.*;
import android.widget.*;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.*;

public class MainActivity extends Activity {
    static final int LIME = Color.rgb(223,255,0);
    static final int INK = Color.rgb(12,17,17);
    static final int CYAN = Color.rgb(0,216,229);
    static final int MAGENTA = Color.rgb(240,42,152);
    static final int WHITE = Color.rgb(235,240,232);
    static final int REQ_HOME = 90;

    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        getWindow().setNavigationBarColor(LIME);
        getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_FULLSCREEN | View.SYSTEM_UI_FLAG_LAYOUT_STABLE | View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR);
        if (isHomeRoleHeld()) showLauncher(); else showSetup();
    }

    @Override protected void onResume() {
        super.onResume();
        if (isHomeRoleHeld() && !(getWindow().getDecorView() instanceof MarathonHomeView)) showLauncher();
    }

    private boolean isHomeRoleHeld() {
        if (Build.VERSION.SDK_INT >= 29) {
            RoleManager rm=(RoleManager)getSystemService(ROLE_SERVICE);
            return rm != null && rm.isRoleHeld(RoleManager.ROLE_HOME);
        }
        Intent i=new Intent(Intent.ACTION_MAIN); i.addCategory(Intent.CATEGORY_HOME);
        ResolveInfo r=getPackageManager().resolveActivity(i, PackageManager.MATCH_DEFAULT_ONLY);
        return r!=null && getPackageName().equals(r.activityInfo.packageName);
    }

    private void showSetup() {
        ScrollView scroll=new ScrollView(this); scroll.setBackgroundColor(LIME);
        LinearLayout root=new LinearLayout(this); root.setOrientation(LinearLayout.VERTICAL); root.setPadding(dp(28),dp(42),dp(28),dp(40)); scroll.addView(root);
        TextView t=txt("MARATHON // FOLD8",34,true,INK); root.addView(t);
        TextView s=txt("LAUNCHER INSTALLER  v2.0\nTAU CETI IV // SYSTEM ONLINE",15,true,INK); s.setPadding(0,dp(8),0,dp(26)); root.addView(s);
        TextView d=txt("Эта версия не пытается ломать One UI через Theme Park. Она становится домашним экраном и сама рисует интерфейс Marathon на внешнем и внутреннем дисплеях.",17,false,INK); d.setPadding(0,0,0,dp(22)); root.addView(d);
        Button apply=btn("APPLY MARATHON", v -> applyAll()); root.addView(apply);
        Button preview=btn("PREVIEW WITHOUT SWITCHING HOME", v -> showLauncher()); root.addView(preview);
        TextView note=txt("Что будет применено автоматически:\n• Marathon Home для Fold cover/main\n• кастомные иконки и dock\n• часы, календарь и системная карточка\n• acid yellow-green интерфейс\n• lock wallpaper\n\nAndroid всё равно покажет системное окно выбора домашнего приложения. Это обязательное подтверждение безопасности.",14,false,INK); note.setPadding(0,dp(24),0,0); root.addView(note);
        setContentView(scroll);
    }

    private void applyAll() {
        applyLockWallpaper();
        applySystemWallpaper();
        if (Build.VERSION.SDK_INT >= 29) {
            RoleManager rm=(RoleManager)getSystemService(ROLE_SERVICE);
            if (rm!=null && rm.isRoleAvailable(RoleManager.ROLE_HOME)) {
                startActivityForResult(rm.createRequestRoleIntent(RoleManager.ROLE_HOME), REQ_HOME);
                return;
            }
        }
        startActivity(new Intent(Settings.ACTION_HOME_SETTINGS));
    }

    @Override protected void onActivityResult(int req,int result,Intent data) {
        super.onActivityResult(req,result,data);
        if (req==REQ_HOME) showLauncher();
    }

    private void applyLockWallpaper() {
        Bitmap b=BitmapFactory.decodeResource(getResources(),R.drawable.wallpaper_lock);
        try { WallpaperManager.getInstance(this).setBitmap(b,null,true,WallpaperManager.FLAG_LOCK); } catch(IOException ignored){}
    }
    private void applySystemWallpaper() {
        Bitmap b=BitmapFactory.decodeResource(getResources(),R.drawable.wallpaper_home);
        try { WallpaperManager.getInstance(this).setBitmap(b,null,true,WallpaperManager.FLAG_SYSTEM); } catch(IOException ignored){}
    }

    private void showLauncher() { setContentView(new MarathonHomeView(this)); }
    private TextView txt(String x,int sp,boolean bold,int c){ TextView t=new TextView(this);t.setText(x);t.setTextSize(sp);t.setTextColor(c);if(bold)t.setTypeface(Typeface.DEFAULT_BOLD);return t; }
    private Button btn(String x,View.OnClickListener l){ Button b=new Button(this);b.setText(x);b.setTextSize(17);b.setTextColor(LIME);b.setBackgroundColor(INK);b.setAllCaps(false);b.setOnClickListener(l); LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(-1,dp(64));p.setMargins(0,dp(8),0,dp(8));b.setLayoutParams(p);return b; }
    int dp(int n){return Math.round(n*getResources().getDisplayMetrics().density);}

    public static class MarathonHomeView extends View {
        final Paint p=new Paint(3); final Paint stroke=new Paint(3); final Context c; final PackageManager pm;
        final ArrayList<AppSlot> slots=new ArrayList<>(); final RectF menuRect=new RectF();
        long lastTick=0;
        MarathonHomeView(Context c){ super(c); this.c=c; pm=c.getPackageManager(); setBackgroundColor(LIME); p.setTypeface(Typeface.create(Typeface.MONOSPACE,Typeface.NORMAL)); stroke.setStyle(Paint.Style.STROKE); stroke.setStrokeWidth(2f); loadSlots(); setOnLongClickListener(v->{ Intent i=new Intent(Settings.ACTION_HOME_SETTINGS); c.startActivity(i); return true;}); }

        void loadSlots(){
            String[][] defs={
              {"com.samsung.android.email.provider","Почта","mail"},{"com.google.android.gm","Gmail","gmail"},{"com.ticktick.task","TickTick","calendar"},
              {"com.sec.android.app.shealth","Health","samsung_health"},{"ru.yandex.taxi","ЯндексGo","yandex"},{"com.android.chrome","Chrome","browser"},
              {"com.google.android.apps.youtube.creator","YouTube Studio","youtube"},{"com.android.settings","Настройки","settings"},{"com.idamob.tinkoff.android","Т-Банк","bank"},
              {"ru.sberbankmobile","СберБанк","bank"},{"ru.vtb24.mobilebanking.android","ВТБ","bank"},{"ru.yandex.yandexmaps","Карты","maps"},
              {"ru.yandex.yandexeats","Яндекс Еда","yandex"},{"com.android.vending","Google Play","play_store"},{"org.telegram.messenger","Telegram","telegram"},
              {"com.google.android.calendar","Календарь","calendar"},{"md.obsidian","Obsidian","obsidian"},{"com.google.android.youtube","YouTube","youtube"},
              {"com.whatsapp","WhatsApp","whatsapp"},{"com.vkontakte.android","VK","vk"},{"com.sec.android.app.camera","Камера","camera"},
              {"com.samsung.android.dialer","Телефон","phone"},{"com.samsung.android.messaging","Сообщения","messages"},{"com.sec.android.gallery3d","Галерея","gallery"}
            };
            HashSet<String> seen=new HashSet<>();
            for(String[] d:defs){ if(hasLaunch(d[0])){ slots.add(new AppSlot(d[0],d[1],d[2])); seen.add(d[0]); } }
            Intent q=new Intent(Intent.ACTION_MAIN); q.addCategory(Intent.CATEGORY_LAUNCHER);
            List<ResolveInfo> all=pm.queryIntentActivities(q,0);
            Collections.sort(all,new ResolveInfo.DisplayNameComparator(pm));
            for(ResolveInfo r:all){ if(slots.size()>=30)break; String pkg=r.activityInfo.packageName; if(pkg.equals(c.getPackageName())||seen.contains(pkg))continue; slots.add(new AppSlot(pkg,String.valueOf(r.loadLabel(pm)),null)); seen.add(pkg); }
        }
        boolean hasLaunch(String pkg){ return pm.getLaunchIntentForPackage(pkg)!=null; }
        void launch(AppSlot s){ try{Intent i=pm.getLaunchIntentForPackage(s.pkg); if(i!=null)c.startActivity(i);}catch(Exception ignored){} }

        @Override protected void onDraw(Canvas cn){ super.onDraw(cn); int W=getWidth(),H=getHeight(); boolean inner=getResources().getConfiguration().smallestScreenWidthDp>=600 || W>H*0.85f; drawBackground(cn,W,H,inner); if(inner) drawInner(cn,W,H); else drawCover(cn,W,H); if(System.currentTimeMillis()-lastTick>950){lastTick=System.currentTimeMillis();postInvalidateDelayed(1000);} }

        void drawBackground(Canvas cn,int W,int H,boolean inner){
            cn.drawColor(LIME); p.setColor(Color.argb(20,0,0,0)); p.setStrokeWidth(1); float step=Math.max(34,W/32f); for(float x=0;x<W;x+=step)for(float y=0;y<H;y+=step)cn.drawCircle(x,y,1.2f,p);
            p.setColor(Color.argb(72,12,17,17)); p.setStyle(Paint.Style.STROKE); p.setStrokeWidth(Math.max(2,W/700f)); float cx=inner?W*.73f:W*.5f, cy=inner?H*.30f:H*.45f; float r=Math.min(W,H)*(inner?.24f:.34f); cn.drawCircle(cx,cy,r,p); cn.drawCircle(cx,cy,r*.66f,p); cn.drawLine(cx-r*1.14f,cy,cx+r*1.14f,cy,p); cn.drawLine(cx,cy-r*1.14f,cx,cy+r*1.14f,p); p.setStyle(Paint.Style.FILL);
            p.setColor(INK); for(int i=0;i<8;i++){float y=H*(.08f+i*.11f);cn.drawRect(W*.025f,y,W*.055f,y+3,p);}
        }

        void drawInner(Canvas cn,int W,int H){
            float pad=W*.045f, gap=W*.018f; float leftW=W*.43f; float top=H*.075f; float cardH=H*.22f; float cardW=(leftW-gap)/2f;
            drawClockCard(cn,new RectF(pad,top,pad+cardW,top+cardH));
            drawTasksCard(cn,new RectF(pad+cardW+gap,top,pad+leftW,top+cardH));
            drawCalendarCard(cn,new RectF(pad,top+cardH+gap,pad+cardW,top+cardH*2+gap));
            drawSystemCard(cn,new RectF(pad+cardW+gap,top+cardH+gap,pad+leftW,top+cardH*2+gap));
            text(cn,"MARATHON",W*.67f,H*.30f,Math.max(30,W*.035f),true,INK,Paint.Align.CENTER); text(cn,"TAU CETI IV",W*.67f,H*.345f,Math.max(14,W*.014f),true,INK,Paint.Align.CENTER);
            float gridTop=H*.59f, dockTop=H*.87f; drawGrid(cn,pad,gridTop,W-pad*2,dockTop-gridTop,8,2,0); drawDock(cn,pad,dockTop,W-pad*2,H*.105f,7);
        }

        void drawCover(Canvas cn,int W,int H){
            float pad=W*.07f; text(cn,time(),W*.5f,H*.18f,W*.16f,true,INK,Paint.Align.CENTER); text(cn,dateShort(),W*.5f,H*.235f,W*.035f,true,INK,Paint.Align.CENTER);
            RectF task=new RectF(pad,H*.29f,W-pad,H*.45f); drawTasksCard(cn,task);
            float dockTop=H*.84f; drawGrid(cn,pad,H*.51f,W-pad*2,H*.29f,3,2,0); drawDock(cn,pad,dockTop,W-pad*2,H*.09f,4);
        }

        void drawClockCard(Canvas cn,RectF r){ card(cn,r); text(cn,dateLong().toUpperCase(),r.left+r.width()*.08f,r.top+r.height()*.18f,r.width()*.045f,true,LIME,Paint.Align.LEFT); text(cn,time(),r.left+r.width()*.08f,r.top+r.height()*.61f,r.width()*.17f,true,LIME,Paint.Align.LEFT); text(cn,"MARATHON // TAU CETI IV",r.left+r.width()*.08f,r.bottom-r.height()*.12f,r.width()*.035f,true,LIME,Paint.Align.LEFT); }
        void drawTasksCard(Canvas cn,RectF r){ card(cn,r); text(cn,"ЗАДАЧИ",r.left+r.width()*.07f,r.top+r.height()*.17f,r.width()*.055f,true,LIME,Paint.Align.LEFT); text(cn,"TICKTICK // ОТКРЫТЬ",r.left+r.width()*.07f,r.top+r.height()*.46f,r.width()*.036f,true,WHITE,Paint.Align.LEFT); text(cn,"НАЖМИ НА КАРТОЧКУ",r.left+r.width()*.07f,r.top+r.height()*.65f,r.width()*.030f,false,Color.rgb(160,170,160),Paint.Align.LEFT); text(cn,"MARATHON OS  v2",r.left+r.width()*.07f,r.bottom-r.height()*.09f,r.width()*.026f,true,LIME,Paint.Align.LEFT); }
        void drawCalendarCard(Canvas cn,RectF r){ card(cn,r); Calendar cal=Calendar.getInstance(); String month=new SimpleDateFormat("LLLL yyyy",new Locale("ru")).format(cal.getTime()).toUpperCase(); text(cn,month,r.left+r.width()*.07f,r.top+r.height()*.15f,r.width()*.045f,true,LIME,Paint.Align.LEFT); Calendar first=(Calendar)cal.clone();first.set(Calendar.DAY_OF_MONTH,1); int offset=(first.get(Calendar.DAY_OF_WEEK)+5)%7; int max=cal.getActualMaximum(Calendar.DAY_OF_MONTH); float sx=r.left+r.width()*.10f, sy=r.top+r.height()*.31f, dx=r.width()*.125f, dy=r.height()*.12f; String[] ds={"ПН","ВТ","СР","ЧТ","ПТ","СБ","ВС"}; for(int i=0;i<7;i++)text(cn,ds[i],sx+i*dx,sy,r.width()*.026f,true,Color.rgb(150,160,150),Paint.Align.CENTER); for(int day=1;day<=max;day++){int n=offset+day-1,row=n/7,col=n%7; float x=sx+col*dx,y=sy+(row+1)*dy; if(day==cal.get(Calendar.DAY_OF_MONTH)){p.setColor(LIME);cn.drawRoundRect(new RectF(x-dx*.32f,y-dy*.55f,x+dx*.32f,y+dy*.25f),8,8,p);text(cn,""+day,x,y,r.width()*.03f,true,INK,Paint.Align.CENTER);}else text(cn,""+day,x,y,r.width()*.03f,false,WHITE,Paint.Align.CENTER);} }
        void drawSystemCard(Canvas cn,RectF r){ card(cn,r); text(cn,"СИСТЕМА",r.left+r.width()*.07f,r.top+r.height()*.15f,r.width()*.045f,true,LIME,Paint.Align.LEFT); long total=new android.os.StatFs(android.os.Environment.getDataDirectory().getPath()).getTotalBytes(), free=new android.os.StatFs(android.os.Environment.getDataDirectory().getPath()).getAvailableBytes(); float used=1f-(float)free/(float)total; int batt=((android.os.BatteryManager)c.getSystemService(Context.BATTERY_SERVICE)).getIntProperty(android.os.BatteryManager.BATTERY_PROPERTY_CAPACITY); meter(cn,r,"ХРАНИЛИЩЕ",used,.36f); meter(cn,r,"ЗАРЯД",Math.max(0,batt)/100f,.61f); text(cn,"TAU CETI IV",r.left+r.width()*.07f,r.bottom-r.height()*.09f,r.width()*.027f,true,LIME,Paint.Align.LEFT); }
        void meter(Canvas cn,RectF r,String label,float v,float ypos){ text(cn,label,r.left+r.width()*.07f,r.top+r.height()*ypos,r.width()*.027f,true,WHITE,Paint.Align.LEFT); float x=r.left+r.width()*.07f,y=r.top+r.height()*(ypos+.06f),ww=r.width()*.80f; p.setColor(Color.rgb(45,55,20));cn.drawRect(x,y,x+ww,y+r.height()*.035f,p);p.setColor(LIME);cn.drawRect(x,y,x+ww*Math.max(0,Math.min(1,v)),y+r.height()*.035f,p); }
        void card(Canvas cn,RectF r){ p.setColor(INK);cn.drawRoundRect(r,r.width()*.055f,r.width()*.055f,p); stroke.setColor(Color.argb(120,223,255,0));stroke.setStrokeWidth(2);cn.drawRoundRect(r,r.width()*.055f,r.width()*.055f,stroke); }

        void drawGrid(Canvas cn,float x,float y,float w,float h,int cols,int rows,int start){ float cw=w/cols,ch=h/rows; int max=Math.min(slots.size(),start+cols*rows); for(int i=start;i<max;i++){int j=i-start;float cx=x+(j%cols+.5f)*cw,cy=y+(j/cols+.36f)*ch;drawApp(cn,slots.get(i),cx,cy,Math.min(cw,ch)*.44f,true); slots.get(i).hit.set(cx-cw*.45f,cy-ch*.32f,cx+cw*.45f,cy+ch*.62f);} }
        void drawDock(Canvas cn,float x,float y,float w,float h,int n){ p.setColor(INK);RectF r=new RectF(x,y,x+w,y+h);cn.drawRoundRect(r,h*.28f,h*.28f,p);stroke.setColor(Color.argb(150,223,255,0));stroke.setStrokeWidth(2);cn.drawRoundRect(r,h*.28f,h*.28f,stroke); int count=Math.min(n,slots.size());float cw=w/(count+1);for(int i=0;i<count;i++){float cx=x+(i+1)*cw,cy=y+h*.48f;drawApp(cn,slots.get(i),cx,cy,h*.34f,false);slots.get(i).hit.set(cx-cw*.42f,y,cx+cw*.42f,y+h);} }

        void drawApp(Canvas cn,AppSlot s,float cx,float cy,float radius,boolean label){ RectF tile=new RectF(cx-radius,cy-radius,cx+radius,cy+radius);p.setColor(INK);cn.drawRoundRect(tile,radius*.26f,radius*.26f,p);stroke.setColor(LIME);stroke.setStrokeWidth(Math.max(2,radius*.035f));cn.drawRoundRect(tile,radius*.26f,radius*.26f,stroke); Drawable d=customDrawable(s); if(d!=null){int m=(int)(radius*.24f);d.setBounds((int)tile.left+m,(int)tile.top+m,(int)tile.right-m,(int)tile.bottom-m);d.draw(cn);} if(label)text(cn,shortLabel(s.label),cx,cy+radius*1.55f,Math.max(11,radius*.25f),false,INK,Paint.Align.CENTER); }
        Drawable customDrawable(AppSlot s){ try{ if(s.res!=null){int id=c.getResources().getIdentifier(s.res,"drawable",c.getPackageName());if(id!=0)return c.getDrawable(id);} Drawable d=pm.getApplicationIcon(s.pkg); d.setColorFilter(new android.graphics.PorterDuffColorFilter(LIME,android.graphics.PorterDuff.Mode.SRC_IN)); return d;}catch(Exception e){return null;} }
        String shortLabel(String s){ return s.length()>18?s.substring(0,17)+"…":s; }

        void text(Canvas cn,String s,float x,float y,float sz,boolean bold,int color,Paint.Align align){p.setStyle(Paint.Style.FILL);p.setColor(color);p.setTextSize(sz);p.setTextAlign(align);p.setTypeface(Typeface.create(Typeface.MONOSPACE,bold?Typeface.BOLD:Typeface.NORMAL));cn.drawText(s,x,y,p);}
        String time(){return new SimpleDateFormat("HH:mm",Locale.getDefault()).format(new Date());}
        String dateShort(){return new SimpleDateFormat("dd MMM. yyyy • EEEE",new Locale("ru")).format(new Date()).toUpperCase();}
        String dateLong(){return new SimpleDateFormat("dd MMM. yyyy • EEEE",new Locale("ru")).format(new Date());}

        @Override public boolean onTouchEvent(android.view.MotionEvent e){ if(e.getAction()==MotionEvent.ACTION_UP){float x=e.getX(),y=e.getY();for(AppSlot s:slots)if(s.hit.contains(x,y)){launch(s);return true;} // Tasks card shortcut
                if(getResources().getConfiguration().smallestScreenWidthDp>=600){float W=getWidth(),H=getHeight(),pad=W*.045f,gap=W*.018f,leftW=W*.43f,top=H*.075f,cardH=H*.22f,cardW=(leftW-gap)/2f;RectF task=new RectF(pad+cardW+gap,top,pad+leftW,top+cardH);if(task.contains(x,y)){launchPkg("com.ticktick.task");return true;}}
            }
            return true; }
        void launchPkg(String pkg){try{Intent i=pm.getLaunchIntentForPackage(pkg);if(i!=null)c.startActivity(i);}catch(Exception ignored){}}
    }

    static class AppSlot { final String pkg,label,res; final RectF hit=new RectF(); AppSlot(String p,String l,String r){pkg=p;label=l;res=r;} }
}
