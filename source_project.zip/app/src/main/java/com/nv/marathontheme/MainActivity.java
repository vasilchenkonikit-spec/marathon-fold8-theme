package com.nv.marathontheme;

import android.app.Activity;
import android.app.WallpaperManager;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Color;
import android.os.Bundle;
import android.provider.Settings;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import java.io.IOException;

public class MainActivity extends Activity {
    private static final int LIME = Color.rgb(215,255,0);
    private static final int INK = Color.rgb(16,21,21);
    private static final int CYAN = Color.rgb(0,216,229);
    private static final int WHITE = Color.rgb(235,240,232);

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        ScrollView scroll = new ScrollView(this);
        scroll.setBackgroundColor(LIME);

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(22), dp(26), dp(22), dp(32));
        scroll.addView(root);

        TextView title = text("MARATHON // FOLD8", 30, true, INK);
        root.addView(title);

        TextView sub = text("RUNNER THEME INSTALLER\nSYSTEM ONLINE", 14, true, CYAN);
        sub.setPadding(0, dp(8), 0, dp(24));
        root.addView(sub);

        TextView desc = text(
            "Автоматизированный пакет: обои + Marathon icon pack + быстрый доступ к Samsung Good Lock / Theme Park.",
            16, false, INK);
        desc.setPadding(0, 0, 0, dp(18));
        root.addView(desc);

        root.addView(button("1 // HOME WALLPAPER", v -> setWallpaper(R.drawable.wallpaper_cover_home, WallpaperManager.FLAG_SYSTEM)));
        root.addView(button("2 // LOCK WALLPAPER", v -> setWallpaper(R.drawable.wallpaper_cover_lock, WallpaperManager.FLAG_LOCK)));
        root.addView(button("3 // ОТКРЫТЬ THEME PARK", v -> openPackage("com.samsung.android.themedesigner")));
        root.addView(button("4 // ОТКРЫТЬ GOOD LOCK", v -> openPackage("com.samsung.android.goodlock")));
        root.addView(button("5 // HOME UP", v -> openPackage("com.samsung.android.app.homestar")));
        root.addView(button("6 // KEYS CAFE", v -> openPackage("com.samsung.android.keyscafe")));
        root.addView(button("7 // QUICKSTAR", v -> openPackage("com.samsung.android.qstuner")));
        root.addView(button("8 // LOCKSTAR", v -> openPackage("com.samsung.systemui.lockstar")));
        root.addView(button("СКОПИРОВАТЬ ПАЛИТРУ", v -> copyPalette()));

        TextView steps = text(
            "\nИконки:\nTheme Park → Icon → Create new → Icon pack → Marathon Theme → Apply\n\n" +
            "Палитра:\n#D7FF00  lime\n#101515  ink\n#00D8E5  cyan\n#F02A98  magenta\n#EBF0E8  text\n\n" +
            "Важно: Android не разрешает стороннему APK без root/ADB молча менять Quick Panel, LockStar или Keys Cafe. " +
            "Установщик открывает нужный модуль сразу, а иконки применяются одним пакетом.",
            15, false, INK);
        steps.setPadding(0, dp(12), 0, 0);
        root.addView(steps);

        setContentView(scroll);
    }

    private void setWallpaper(int resId, int flag) {
        Bitmap b = BitmapFactory.decodeResource(getResources(), resId);
        try {
            WallpaperManager.getInstance(this).setBitmap(b, null, true, flag);
            Toast.makeText(this, "Wallpaper applied", Toast.LENGTH_SHORT).show();
        } catch (IOException e) {
            Toast.makeText(this, "Не удалось применить: " + e.getMessage(), Toast.LENGTH_LONG).show();
        }
    }

    private void openPackage(String pkg) {
        Intent i = getPackageManager().getLaunchIntentForPackage(pkg);
        if (i != null) {
            startActivity(i);
        } else {
            Toast.makeText(this, "Модуль не найден. Открываю настройки.", Toast.LENGTH_SHORT).show();
            startActivity(new Intent(Settings.ACTION_SETTINGS));
        }
    }

    private void copyPalette() {
        String s = "MARATHON FOLD8\nLIME #D7FF00\nBRIGHT #EAFF16\nDARK LIME #B4D600\nINK #101515\nNAVY #071217\nCYAN #00D8E5\nMAGENTA #F02A98\nTEXT #EBF0E8";
        ClipboardManager cm = (ClipboardManager)getSystemService(Context.CLIPBOARD_SERVICE);
        cm.setPrimaryClip(ClipData.newPlainText("Marathon palette", s));
        Toast.makeText(this, "Палитра скопирована", Toast.LENGTH_SHORT).show();
    }

    private Button button(String label, View.OnClickListener click) {
        Button b = new Button(this);
        b.setText(label);
        b.setTextSize(15);
        b.setTextColor(WHITE);
        b.setBackgroundColor(INK);
        b.setAllCaps(false);
        b.setGravity(Gravity.CENTER_VERTICAL);
        b.setPadding(dp(18), 0, dp(18), 0);
        b.setOnClickListener(click);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, dp(58));
        lp.setMargins(0, dp(7), 0, dp(7));
        b.setLayoutParams(lp);
        return b;
    }

    private TextView text(String value, int sp, boolean bold, int color) {
        TextView t = new TextView(this);
        t.setText(value);
        t.setTextSize(sp);
        t.setTextColor(color);
        if (bold) t.setTypeface(android.graphics.Typeface.DEFAULT_BOLD);
        return t;
    }

    private int dp(int n) {
        return Math.round(n * getResources().getDisplayMetrics().density);
    }
}
